Azure Cloud is one of the primary options for cloud-based deployment of ML models, along with others such as AWS, GCP, Alibaba etc.

## Why the use of the Azure App Service for this project?

The Azure Web App provides a host service that developers can use it to develop mobile or web app. Apart from this the developer can use to build API apps or Logic apps, which provides integration with SaaS. It replaces several separate Azure services, which includes Azure Website, Azure Mobile services and Azure BizTalk services gives you a single product called Azure App services.
